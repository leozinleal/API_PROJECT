<?php

namespace App\Controller;
use App\Entity\Movie;
use App\Repository\MovieRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;

#[Route('/default')]
class DefaultController extends AbstractController
{
    #[Route('/', name: 'get_all_movie')]
    public function index(MovieRepository $movieRepository): JsonResponse
    {
        $movies = $movieRepository->findAll();
        return $this->json($movies);
    }
    #[Route('/new', name: 'create_new_movie')]
    public function newMovie(EntityManagerInterface $em): JsonResponse
    {
        $movie = new Movie();
        $movie->setDescription("Description Filme 1");
        $movie->setTitle("Title Filme 1");

        $em->persist($movie);
        $em->flush();
        
        return $this->json("Movie Saved");
    }
}
